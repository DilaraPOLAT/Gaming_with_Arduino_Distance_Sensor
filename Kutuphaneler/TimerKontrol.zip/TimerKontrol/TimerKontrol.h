#ifndef TimerKontrol_H
#define TimerKontrol_H

#include <Arduino.h>

class TimerKontrol
{
    public:
        TimerKontrol();
        void TimerAyarlamasi();
};

#endif